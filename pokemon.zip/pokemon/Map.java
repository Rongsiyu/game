package pokemon;

import java.awt.image.BufferedImage;

import game.App;

public class Map {
BufferedImage mainbg=App.getImg("/pokemon/imgs/bg/bg1.png");
int x=-4200,y=-6850;
BufferedImage home1=App.getImg("/pokemon/imgs/room/home1.jpg");
BufferedImage battlefiled=App.getImg("/pokemon/imgs/battlefiled/background.png");

int x1=0,y1=0;
Door door=new Door();
chukou jiantou =new chukou();
public void  maprepaint(int mapnum){
	switch(mapnum){
	case 0:x=-3320;y=-5460;break;
	case 1:x1=0;y1=0;break;
	}
}
public void move(int mapnumber,int fangxiang){
	switch(mapnumber){
	case 0:{
		switch(fangxiang){
		//��������
		case 0: y+=20; door.y+=20;break;
		case 1:y-=20; door.y-=20;break;	
		case 2:x+=20; door.x+=20;break;
		case 3:x-=20; door.x-=20;break;
		}
		
	}break;
	case 1:{
		switch(fangxiang){
		//��������
		case 0: y1+=20;jiantou.y+=20; break;
		case 1:y1-=20;jiantou.y-=20;break;
		case 2:x1+=20;jiantou.x+=20;break;
		case 3:x1-=20;jiantou.x-=20;break;
		}
		
	}break;
	}
}
}
