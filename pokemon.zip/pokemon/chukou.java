package pokemon;

import java.awt.image.BufferedImage;

public class chukou {
	BufferedImage chukou=App.getImg("/pokemon/imgs/room/1.png");
	int x=385;
	int y=460;
	public void chukourepaint(){
		x=385;
		y=460;
	}
}
