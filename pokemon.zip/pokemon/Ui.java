package pokemon;

import java.awt.image.BufferedImage;

import game.App;

public class Ui {
BufferedImage duihuakuang =App.getImg("/pokemon/imgs/ui/duihuakuang.png");
BufferedImage zdduihuakuang =App.getImg("/pokemon/imgs/ui/1.png");
BufferedImage xuanze =App.getImg("/pokemon/imgs/ui/xuanze.png");
BufferedImage duimianxuetiao =App.getImg("/pokemon/imgs/ui/duimianxuetiao.png");
BufferedImage xuetiao =App.getImg("/pokemon/imgs/ui/xuetiao.png");
BufferedImage duihuakuang2 =App.getImg("/pokemon/imgs/ui/duihuakuang2.png");
int x=0;
int y=380;
int x1=250,y1=380;
int xuanzex=273,xuanzey=405,xuanzex1=273,xuanzey1=405,xuanzex2=411,xuanzey2=405,xuanzex3=273,xuanzey3=451,xuanzex4=411,xuanzey4=451;
int  xuanzexx0=20,xuanzeyy0=405,xuanzexx=20,xuanzeyy=405,xuanzexx1=205,xuanzeyy1=405,xuanzexx2=20,xuanzeyy2=460,xuanzexx3=205,xuanzeyy3=460;
public void move(int fangxiang ){
	switch(fangxiang ){
	case 0:xuanzey=405;break;
	case 1:xuanzey=451;break;
	case 2:xuanzex=273;break;
	case 3:xuanzex=411;break;
	}
}
public void move1(int fangxiang ){
	switch(fangxiang ){
	case 0:xuanzeyy0=405;break;
	case 1:xuanzeyy0=460;break;
	case 2:xuanzexx0=20;break;
	case 3:xuanzexx0=205;break;
	}
}
public void xuanze(){
	
}
}
