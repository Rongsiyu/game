package pokemon;

import java.awt.image.BufferedImage;

public class Ep extends Person {

BufferedImage one;
boolean up,left,right,down;
int a =1,w=1,s=1,d=1;
public Ep(){
	x1=385;
	y1=410;
	x=250;
	y=180;
	
	 me=App.getImg("/pokemon/imgs/ep/zs1.png");
	 }
public void move(int fangxiang){
	switch(fangxiang){
	//��������
	case 0: y+=20; break;
	case 1:y-=20; break;	
	case 2:x+=20; break;
	case 3:x-=20; break;
	}
}
public void ai(){
	
}
public void imgchange(){
	if(down){
		
		me=App.getImg("/pokemon/imgs/ep/zs"+s+".png");
		down=false;
		s++;
		if(s==5)
		{s=1;}
		
	}
	if(left){
		me=App.getImg("/pokemon/imgs/ep/za"+a+".png");
		left=false;
		a++;
		if(a==5)
		{a=1;}
	}
	if(right){
		me=App.getImg("/pokemon/imgs/ep/zd"+d+".png");
		right =false;
		d++;
		if(d==5)
		{d=1;}
	}
	if(up){
		me=App.getImg("/pokemon/imgs/ep/zw"+w+".png");
	up=false;
	w++;
	if(w==5)
	{w=1;}
	}
}
}
