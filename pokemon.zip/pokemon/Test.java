package pokemon;

import javax.swing.JFrame;

public class Test {
public static void main(String args[]){
	Gameframe gameframe=new Gameframe();
	Gamepanel gamepanel=new Gamepanel(gameframe);//����������̽�����
	gameframe.setVisible(true);
	gameframe.add(gamepanel);
	gamepanel.action();
}
}



