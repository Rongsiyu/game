package pokemon;

import java.awt.image.BufferedImage;

public class Battlefield {
BufferedImage field =App.getImg("/pokemon/imgs/battlefiled/8.jpg");

}
