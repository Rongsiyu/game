package pokemon;

import java.awt.image.BufferedImage;

public class Door {
BufferedImage door1=App.getImg("/pokemon/imgs/room/door1.jpg");
int x=135;
int y=265;
public void doorrepaint(){
	x=143;y=228;
}

}
