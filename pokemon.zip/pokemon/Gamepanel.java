package pokemon;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.swing.JPanel;

public class Gamepanel extends JPanel {
	Map map = new Map();
	Me me = new Me();
	Ep ep = new Ep();
	Pokemons pokemons = new Pokemons();
	pokemon pokemon = new pokemon();
	Ui ui = new Ui();
	int x = 0, y;
	int mapnumber = 0;
	boolean zhandou = false;
	boolean duihuakuang2 = false;
	String[][] jinen;
	double shanghai;
	double duimianshanghai;
	int xueliang;
	double duimianxueliang;
	double[] zhongzuzhi;
	double[] duiminazhongzuzhi;
	boolean duizhanxuanze;
	boolean duihuakuang=false;
	boolean xuetiao =false;
	String jinenname;
	String duimianjinenname;
	int f=0;
	public void action() {
	Thread a=new Thread(){
			public void run() {
				while (true) {
					if (zhandou == false) {
						epmove();
						repaint();
						try {
							Thread.sleep(3000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					else repaint();
					
		
					
				}

			}

			private void duizhanxuanze() {

			}

			

	};
	
		a.start();
		
	}

	// �û����������Զ��ƶ�
	public void epmove() {
		Random r = new Random();
		int fangxiang = r.nextInt(4);// ���ȡ0��3
		switch (fangxiang) {
		case 0: {
			for (int i = 0; i < 4; i++) {
				ep.up = true;
				ep.imgchange();
				ep.y -= 10;
				repaint();
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
			break;
		case 1: {
			for (int i = 0; i < 4; i++) {
				ep.down = true;
				ep.imgchange();
				ep.y += 10;
				repaint();
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
			break;
		case 2: {
			for (int i = 0; i < 4; i++) {
				ep.left = true;
				ep.imgchange();
				ep.x -= 10;
				repaint();
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
			break;
		case 3: {
			for (int i = 0; i < 4; i++) {
				ep.right = true;
				ep.imgchange();
				ep.x += 10;
				repaint();
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
			break;
		}

	}

	public Gamepanel(Gameframe frame) {
		// ���������������࣬����������һ��������д�䷽����
		KeyAdapter kd = new KeyAdapter() {
			// 2ȷ����Ҫ�����ļ����¼�
			public void keyPressed(KeyEvent e) {
				int keyCode = e.getKeyCode();
				int mx = me.x, my = me.y;
				if (keyCode == KeyEvent.VK_UP) {
					if (zhandou == false) {
						if (mapnumber == 0) {
							ep.move(0);
							pokemons.move(0);
							map.move(mapnumber, 0);
							me.up = true;
							me.imgchange();
						}
						if (mapnumber == 1) {
							map.move(mapnumber, 0);
							me.up = true;
							me.imgchange();
						}

					}
					// ս�����濪ʼ���Ƽ�ͷ���ƶ�
					else if (duihuakuang2 == false)
						ui.move(0);
					else
						ui.move1(0);

				} else if (keyCode == KeyEvent.VK_DOWN) {
					if (zhandou == false) {
						if (mapnumber == 0) {
							ep.move(1);
							pokemons.move(1);
							map.move(mapnumber, 1);
							me.down = true;
							me.imgchange();
						}
						if (mapnumber == 1) {
							map.move(mapnumber, 1);
							me.down = true;
							me.imgchange();
						}
					} else if (duihuakuang2 == false)
						ui.move(1);
					else
						ui.move1(1);

				} else if (keyCode == KeyEvent.VK_RIGHT) {
					if (zhandou == false) {
						if (mapnumber == 0) {
							ep.move(3);
							pokemons.move(3);
							map.move(mapnumber, 3);
							me.right = true;
							me.imgchange();
						}
						if (mapnumber == 1) {
							map.move(mapnumber, 3);
							me.right = true;
							me.imgchange();
						}
					} else if (duihuakuang2 == false)
						ui.move(3);
					else
						ui.move1(3);
				} else if (keyCode == KeyEvent.VK_LEFT) {
					if (zhandou == false) {
						if (mapnumber == 0) {
							ep.move(2);
							pokemons.move(2);
							map.move(mapnumber, 2);
							me.left = true;
							me.imgchange();
						}
						if (mapnumber == 1) {
							map.move(mapnumber, 2);
							me.left = true;
							me.imgchange();
						}
					}

					else if (duihuakuang2 == false)
						ui.move(2);
					else
						ui.move1(2);
				} else if (keyCode == KeyEvent.VK_SPACE) {

					if (zhandou == false) {
						if (pokemons.x <= 250 && (pokemons.x + pokemons.qiaoyinhou.getWidth() >= 250)
								&& (pokemons.y <= 280 && (pokemons.y + pokemons.qiaoyinhou.getHeight() >= 280))) {
							zhandou = true;
							xuetiao=false;
							// ս����ʼ
							zhongzuzhi = pokemon.getzhongzuzhi(pokemon.first);
							duiminazhongzuzhi = pokemon.getzhongzuzhi(pokemon.one);
							shanghai = 0;
							duimianshanghai = 0;
							ui.xuanzex=ui.xuanzex1;ui.xuanzey=ui.xuanzey1;
							ui.xuanzexx0=ui.xuanzexx;ui.xuanzeyy0=ui.xuanzeyy;
							duihuakuang=false;
							duihuakuang2=false;
							duizhanxuanze=false;
							f=0;
						}

					} else {

						if (ui.xuanzex == ui.xuanzex1 && ui.xuanzey == ui.xuanzey1) {
							duihuakuang2 = true;}
						 if(duihuakuang2==true&&(f++!=0)){
							if (ui.xuanzexx0 == ui.xuanzexx && ui.xuanzeyy0 == ui.xuanzeyy) {
								jinen = pokemon.getjinen(pokemon.first);
								duihuakuang = true;
								duizhanxuanze=true;
								try {
									 jinenname=jinen[0][0];
									int one = Integer.parseInt(jinen[0][2]);

									shanghai += (pokemon.getzhongzuzhi(pokemon.first)[1]) * one / 100;

								} catch (NumberFormatException e1) {

									e1.printStackTrace();
								}
								duizhan();
							}
							if (ui.xuanzexx0 == ui.xuanzexx1 && ui.xuanzeyy0 == ui.xuanzeyy1) {
								jinen = pokemon.getjinen(pokemon.first);
								duihuakuang = true;
								duizhanxuanze=true;
								try {
									 jinenname=jinen[1][0];
									int two = Integer.parseInt(jinen[1][2]);
									shanghai += (pokemon.getzhongzuzhi(pokemon.first)[1]) * two / 100;

								} catch (NumberFormatException e1) {

									e1.printStackTrace();

								}
								duizhan();
							}
							if (ui.xuanzexx0 == ui.xuanzexx2 && ui.xuanzeyy0 == ui.xuanzeyy2) {
								jinen = pokemon.getjinen(pokemon.first);
								duihuakuang= true;
								duizhanxuanze=true;
								try {
									 jinenname=jinen[2][0];
									int three = Integer.parseInt(jinen[2][2]);
									shanghai += (pokemon.getzhongzuzhi(pokemon.first)[1]) * three / 100;

								} catch (NumberFormatException e1) {

									e1.printStackTrace();

								}
								duizhan();
							}
							if (ui.xuanzexx0 == ui.xuanzexx3 && ui.xuanzeyy0 == ui.xuanzeyy3) {
								jinen = pokemon.getjinen(pokemon.first);
								duihuakuang = true;
								duizhanxuanze=true;
								try {
									 jinenname=jinen[3][0];
									int four = Integer.parseInt(jinen[3][2]);
									shanghai += (pokemon.getzhongzuzhi(pokemon.first)[1]) * four / 100;

								} catch (NumberFormatException e1) {

									e1.printStackTrace();

								}
								duizhan();
							}
							
						}
						if (ui.xuanzex == ui.xuanzex4 && ui.xuanzey == ui.xuanzey4) {
							zhandou = false;

						}
						if(xuetiao==true){
							
							jiezhangxitong();
							zhandou=false;
						}
					}
				} else if (keyCode == KeyEvent.VK_SHIFT) {
					if(duihuakuang==true){
						duihuakuang =false;
						
					}
					else if(duihuakuang2==true){
					duihuakuang2 = false;
					ui.xuanzexx0=ui.xuanzexx;
					ui.xuanzeyy0=ui.xuanzeyy;
					f=0;
					}
				}
				if (map.door.x <= 250 && (map.door.x + map.door.door1.getWidth() >= 250)
						&& (map.door.y <= 280 && (map.door.y + map.door.door1.getHeight() >= 280))) {

					mapnumber = 1;

				}
				if (map.jiantou.x <= 385 && (map.jiantou.x + map.jiantou.chukou.getWidth() >= 385)
						&& (map.jiantou.y <= 410 && (map.jiantou.y + map.jiantou.chukou.getHeight() >= 410))) {
					map.jiantou.chukourepaint();
					map.maprepaint(mapnumber);
					mapnumber = 0;
					
				}
				//ս������Ψһˢ�����
				repaint();
			
			}
		};
		// �����������뵽����ļ�������
		frame.addKeyListener(kd);
		
	}
	public void jiezhangxitong(){
		if(xueliang==0){
			zhandou=false;
		}
		if(duimianxueliang==0){
			//��Ӯ���޸ľ���
			//�Ȼ���ҵľ���ľ�������
			int [] a=pokemon.getjinyan(pokemon.first);
			int [] b=pokemons.getjinyan(pokemons.one);
			a[2]+=b[1];
			
			pokemon.first.set(8, a);
			if(a[2]>=a[0]){
				String denji=pokemon.getdenji(pokemon.first);
				int dengji=Integer.parseInt(denji);
				pokemon.first.set(3, dengji+"");
			}
			
		}
	}
	public void duizhan() {
		jinen = pokemon.getjinen(pokemons.one);

		try {
			Random random = new Random();
			int i = random.nextInt(4);
			int jinenshanghai = Integer.parseInt(jinen[i][2]);
			duimianjinenname=jinen[i][0];
			duimianshanghai += (pokemon.getzhongzuzhi(pokemons.one)[1]) * jinenshanghai / 100;

		} catch (NumberFormatException e1) {

			e1.printStackTrace();

		}
	}

	public void paint(Graphics g) {

		if (zhandou) {
			g.drawImage(map.battlefiled, 0, 0, 500, 500, null);
			if (duihuakuang2 == false) {

				g.drawImage(ui.duihuakuang, ui.x, ui.y, 500, 110, null);
				g.drawImage(ui.zdduihuakuang, ui.x1, ui.y1, null);
				g.drawImage(ui.xuanze, ui.xuanzex, ui.xuanzey, null);
			} else {// �������ܶԻ���
				if(duihuakuang==false){
				g.drawImage(ui.duihuakuang2, ui.x, ui.y, 500, 110, null);
				g.setColor(Color.BLACK);
				g.setFont(new Font("����", Font.BOLD, 18));
				jinen = pokemon.getjinen(pokemon.first);
				g.drawString(jinen[0][0], 40, 420);
				g.drawString(jinen[1][0], 220, 420);
				g.drawString(jinen[2][0], 40, 470);
				g.drawString(jinen[3][0], 220, 470);
				g.drawImage(ui.xuanze, ui.xuanzexx0, ui.xuanzeyy0, null);
				if (ui.xuanzexx0 == ui.xuanzexx && ui.xuanzeyy0 == ui.xuanzeyy) {
					g.drawString(jinen[0][1], 420, 468);
					g.drawString(jinen[0][3], 420, 420);
					g.drawString(jinen[0][3], 455, 420);
					System.out.println("3");
				}
				if (ui.xuanzexx0 == ui.xuanzexx1 && ui.xuanzeyy0 == ui.xuanzeyy1) {
					g.drawString(jinen[1][1], 420, 468);
					g.drawString(jinen[1][3], 420, 420);
					g.drawString(jinen[1][3], 455, 420);
				}
				if (ui.xuanzexx0 == ui.xuanzexx2 && ui.xuanzeyy0 == ui.xuanzeyy2) {
					g.drawString(jinen[2][1], 420, 468);
					g.drawString(jinen[2][3], 420, 420);
					g.drawString(jinen[2][3], 455, 420);
				}
				if (ui.xuanzexx0 == ui.xuanzexx3 && ui.xuanzeyy0 == ui.xuanzeyy3) {
					g.drawString(jinen[3][1], 420, 468);
					g.drawString(jinen[3][3], 420, 420);
					g.drawString(jinen[3][3], 455, 420);
				}
				}
				else if(duihuakuang==true){
					g.setColor(Color.BLACK);
					g.setFont(new Font("����", Font.BOLD, 18));
					g.drawImage(ui.duihuakuang, ui.x, ui.y, 500, 110, null);
					g.drawString(pokemon.getname(pokemon.first)+"ʹ����"+jinenname, 20, 420);
					g.drawString(pokemons.getname(pokemons.one)+"ʹ����"+duimianjinenname, 20, 450);
					
				}
				
			}

			// ���������ı����ε�����
			g.drawImage(pokemons.getphoto(pokemons.one), 330, 110, 100, 100, null);
			g.drawImage(ui.duimianxuetiao, 20, 80, 240, 80, null);
			g.setColor(Color.BLACK);
			g.setFont(new Font("����", Font.BOLD, 18));
			g.drawString(pokemons.getname(pokemons.one), 40, 110);
			g.drawString(pokemons.getdenji(pokemons.one), 215, 113);
			Graphics2D g2d = (Graphics2D) g;
			g2d.setStroke(new BasicStroke(10));

			// Line2D lin = new Line2D.Float(223, 130, 118, 130);
			// ���������double����
			int z = (int) (223 - ((shanghai / pokemon.getzhongzuzhi(pokemon.one)[0]) * 93));
			Line2D lin = new Line2D.Float(223, 130, z < 118 ? 118 : z, 130);
			g2d.draw(lin);
			duimianxueliang= (int )(pokemons.getzhongzuzhi(pokemons.one)[0]-shanghai);
			if(duimianxueliang<0)
				duimianxueliang=0;
			if (z <= 118)
				xuetiao = true;
			// �����Լ��ı�����
			g.drawImage(pokemon.getphoto(pokemon.first), 100, 283, 100, 100, null);
			g.drawImage(ui.xuetiao, 245, 270, null);
			g.drawString(pokemon.getname(pokemon.first), 304, 302);
			g.drawString(pokemon.getdenji(pokemon.first), 447, 302);
			int x = (int) (477 - ((duimianshanghai / pokemon.getzhongzuzhi(pokemon.first)[0]) * 109));
			Line2D lin1 = new Line2D.Float(477, 324, x < 368 ? 368 : x, 324);
			g2d.draw(lin1);
			if (x <= 368){
				xuetiao = true;
			}
			// ��Ѫ���ַ�
			xueliang= (int )(pokemon.getzhongzuzhi(pokemon.first)[0]-duimianshanghai);
			if(xueliang<0)
				xueliang=0;
			g.drawString(xueliang+"", 450, 357);
			g.drawString(pokemon.getzhongzuzhi(pokemon.first)[0] + "", 400, 357);

		}
		// ��������ͼ
		else if (mapnumber == 0) {
			g.drawImage(map.mainbg, map.x, map.y, 9000, 9000, null);
			g.drawImage(map.door.door1, map.door.x, map.door.y, null);
			g.drawImage(me.me, me.x, me.y, null);
			g.drawImage(ep.me, ep.x, ep.y, null);
			g.drawImage(pokemons.qiaoyinhou, pokemons.x, pokemons.y, null);

		} else if (mapnumber == 1) {
			g.drawImage(map.home1, map.x1, map.y1, 500, 500, null);
			g.drawImage(map.jiantou.chukou, map.jiantou.x, map.jiantou.y, null);
			g.drawImage(me.me, me.x1, me.y1, null);
		}

	}
}
