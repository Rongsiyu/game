package pokemon;



public class Me extends Person {
	boolean up,left,right,down;
	int a =1,w=1,s=1,d=1;
	public Me(){
		x1=385;
		y1=410;
		x=250;
		y=250;
		
		 me=App.getImg("/pokemon/imgs/person/zs1.png");
		 }
	public void move(int x,int y){
		
	}
	public void imgchange(){
		if(down){
			
			me=App.getImg("/pokemon/imgs/person/zs"+s+".png");
			down=false;
			s++;
			if(s==5)
			{s=1;}
			
		}
		if(left){
			me=App.getImg("/pokemon/imgs/person/za"+a+".png");
			left=false;
			a++;
			if(a==5)
			{a=1;}
		}
		if(right){
			me=App.getImg("/pokemon/imgs/person/zr"+d+".png");
			right =false;
			d++;
			if(d==5)
			{d=1;}
		}
		if(up){
			me=App.getImg("/pokemon/imgs/person/zw"+w+".png");
		up=false;
		w++;
		if(w==5)
		{w=1;}
		}
	}
}
