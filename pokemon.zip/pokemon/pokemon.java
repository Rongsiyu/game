package pokemon;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.LinkedList;

public class pokemon extends Pokemons {
	//ArrayList<Object>first=new ArrayList<Object>();
	public ArrayList first=new ArrayList(four);
	
	//���� �ɹ�
	/*public static void main(String args[]){
		pokemon a=new pokemon();
		a.first.set(0, "��������");
		String name =(String)a.first.get(0);
		String name1 =(String)a.four.get(0);
		System.out.println(name);
		System.out.println(name1);
	}*/
}
