package pokemon;

import java.awt.image.BufferedImage;
import java.nio.BufferUnderflowException;

public class Person {
	int x,y,x1,y1;
	BufferedImage me;

}
